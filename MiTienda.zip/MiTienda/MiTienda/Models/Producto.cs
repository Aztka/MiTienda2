﻿using System.ComponentModel.DataAnnotations;

namespace MiTienda.Models
{
    public class Producto
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Nombre { get; set; }
        
        [Required]
        public string Descripcion { get; set; }

        [Required]
        [Display(Name = "Precio producto")]
        [Range(0, 1000000, ErrorMessage ="Ingresa valores de 0 (gratis) a $1.000.000")]
        public double Precio { get; set; }
    }
}
