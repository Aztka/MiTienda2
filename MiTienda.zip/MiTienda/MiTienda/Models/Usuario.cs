﻿using System.ComponentModel.DataAnnotations;

namespace MiTienda.Models
{
    public class Usuario
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage ="Ingrese el nombre")]
        [StringLength(50,ErrorMessage ="Limite de caracteres")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "Ingrese el apellido")]
        [StringLength(50, ErrorMessage = "Limite de caracteres")]
        public string Apellido { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime FechaNacimiento { get; set; }

        [Required]
        [EmailAddress]
        public string Correo { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        // Reglas de negocios
        // 10.000.111-1
        // 10000000 - dv
        // 19123123-K
        // 1912 3123 K

        [MinLength(8)]
        [MaxLength(9)]
        public string? Run { get; set; }

        [DataType(DataType.PhoneNumber)]
        public int Telefono { get; set; }
    }
}
